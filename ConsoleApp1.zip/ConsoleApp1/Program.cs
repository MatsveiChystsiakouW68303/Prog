﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            //Zadanie1();
            //Zadanie2();
            zadanie3();
        }
        static void Zadanie1()
        {
            licz liczba1 = new licz(0);

            //Console.WriteLine(liczba1.value);
            
            liczba1.Dodaj(23);
            liczba1.pisz();
            //Console.WriteLine(liczba1.value);

            liczba1.Odejmuj(35);
            liczba1.pisz();
            //Console.WriteLine(liczba1.value);
            
            liczba1.Dodaj(883);
            liczba1.pisz();
            //Console.WriteLine(liczba1.value);


        }
        static void Zadanie2()
        {
            Sumator s1 = new Sumator(new int[] { 2, 4, 5 });
            int[] tab = { 5, 10, 12,36,-2,35,98 };
            Sumator s2 = new Sumator(tab);
            Console.WriteLine("suma " + s1.suma());
            Console.WriteLine("suma " + s2.SumaPodziel2());
            s2.piszpoindekcach(-5, 40);
        }
        static void zadanie3()
        {
            MyDate dzisiaj = new MyDate();
            Console.WriteLine(dzisiaj.data);
            dzisiaj.setData(new DateTime(1979, 07, 28, 22, 35, 5));
            Console.WriteLine(dzisiaj.setData());
            dzisiaj.piszdate();
        }
    }
}
