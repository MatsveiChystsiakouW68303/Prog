﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class licz
    {
        public int value;
        public int Dodaj(int a){
            value+=a;
            return value;
            }
        public int Odejmuj(int a)
        {
            value -= a;
            return value;
        }
        public void pisz()
        {
            Console.WriteLine(value);
        }
        public licz(int value)
        {
            this.value = value;

        }
    }
}
