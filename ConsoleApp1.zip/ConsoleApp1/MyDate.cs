﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class MyDate
    {
        private DateTime data;
        public MyDate()
        {
            data = DateTime.Now;
        }
        public DateTime getDate()
        {
            return data;
        }
        public void setData(DateTime nowa)
        {
            data = DateTime.Now;
        }
        public void piszdate()
        {
            Console.WriteLine(data);
        }
    }
}
