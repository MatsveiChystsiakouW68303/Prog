﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Sumator
    {
        public int[] liczby;

        public int suma()
        {
            int wynik = 0;
            for (int i=0; i<liczby.Length; i++)
            {
                wynik += liczby[i];
            }

            return wynik;
        }
        public int SumaPodziel2()
        {
            int wynik = 0;
            foreach(var liczba in liczby)
            {
                if (liczba % 2 == 0)
                
                    wynik += liczba;
                
            }

            return wynik;
        }
        
        public Sumator(int[] liczby1)
        {
            liczby = liczby1;
            
        }
        public int IleElementów()
        {
            return this.liczby.Length;
        }
        public void piszpoindekcach(int lowindex,int highindex)
        {
            if (lowindex < 0)
                lowindex = 0;
            if (highindex > liczby.Length)
                highindex = liczby.Length;
            for(int i=lowindex; i<liczby.Length;i++)
            {
                Console.Write(liczby[i]+" ");
            }

        }
    }
}
